angular-fusioncharts
====================

Angular JS Bindings for FusionCharts

### [Demos and Documentation](http://fusioncharts.github.io/angular-fusioncharts/)
